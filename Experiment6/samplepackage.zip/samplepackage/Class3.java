// samplepackage/Class3.java
package samplepackage;
public class Class3
{
	public Class3()
	{
		System.out.println("Hello From Class3 from samplepackage");
	}
}