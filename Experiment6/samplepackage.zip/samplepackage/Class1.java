// samplepackage/Class1.java
package samplepackage;
public class Class1
{
	public Class1()
	{
		System.out.println("Hello From Class1 from samplepackage");
	}
}