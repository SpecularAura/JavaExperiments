// samplepackage/Class2.java
package samplepackage;
public class Class2
{
	public Class2()
	{
		System.out.println("Hello From Class2 from samplepackage");
	}
}