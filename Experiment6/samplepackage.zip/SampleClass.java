import samplepackage.Class1;
class SampleClass
{
	public static void main(String args[])
	{
		samplepackage.Class1 c1 = new samplepackage.Class1();
		samplepackage.Class2 c2 = new samplepackage.Class2();
		samplepackage.Class3 c3 = new samplepackage.Class3();
	}
}